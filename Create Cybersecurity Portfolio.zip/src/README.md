# 🔐 Cybersecurity Portfolio - Trần Hoàng Phúc Quân

Portfolio cá nhân chuyên nghiệp cho lĩnh vực Cybersecurity với theme hacker/cyberpunk hiện đại.

## ✨ Tính năng

- 🎨 **Dark Theme Cyberpunk**: Màu neon xanh tím với hiệu ứng glowing
- 🌧️ **Matrix Rain Background**: Hiệu ứng ma trận động
- ⚡ **Smooth Animations**: Sử dụng Motion (Framer Motion) cho các animation mượt mà
- 📱 **Fully Responsive**: Tối ưu cho mọi thiết bị
- 🎯 **Sections**: Hero, About, Skills, Projects, Certifications, Contact
- 🔄 **Smooth Scrolling**: Navigation mượt mà giữa các sections
- 💬 **Contact Form**: Form liên hệ đầy đủ chức năng
- 🎨 **Modern UI**: Giao diện hiện đại với glassmorphism effects

## 🛠️ Công nghệ sử dụng

- **React** - Framework chính
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **Motion (Framer Motion)** - Animations
- **Lucide React** - Icons
- **TypeScript** - Type safety

## 📁 Cấu trúc thư mục

```
/
├── App.tsx                    # Component chính
├── constants/
│   └── data.js               # Dữ liệu cá nhân (dễ chỉnh sửa)
├── components/
│   ├── Navigation.tsx        # Navigation bar
│   ├── Hero.tsx             # Hero section với typing effect
│   ├── Experience.tsx       # Timeline kinh nghiệm
│   ├── Skills.tsx           # Skills với progress bars
│   ├── Projects.tsx         # Projects showcase
│   ├── Certifications.tsx   # Certifications display
│   ├── Contact.tsx          # Contact form
│   ├── Footer.tsx           # Footer
│   └── MatrixRain.tsx       # Matrix rain effect
└── styles/
    └── globals.css          # Global styles
```

## 🚀 Hướng dẫn chạy dự án

### Yêu cầu
- Node.js 16+ 
- npm hoặc yarn

### Cài đặt và chạy

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## ✏️ Tùy chỉnh nội dung

### 1. Thông tin cá nhân
Chỉnh sửa file `/constants/data.js`:

```javascript
export const personalInfo = {
  name: "Tên của bạn",
  title: "Cybersecurity | Pentest",
  bio: "Bio của bạn...",
  email: "email@example.com",
  // ...
};
```

### 2. Kỹ năng
Thêm/sửa kỹ năng trong `skills` object:

```javascript
export const skills = {
  cybersecurity: [
    { name: "Web Pentest", level: 95, icon: "shield" },
    // Thêm kỹ năng mới...
  ],
  // ...
};
```

### 3. Projects
Thêm project mới trong `projects` array:

```javascript
export const projects = [
  {
    id: 1,
    title: "Tên project",
    description: "Mô tả...",
    tags: ["Python", "Security"],
    github: "https://github.com/...",
    featured: true
  },
  // ...
];
```

### 4. Certifications
Cập nhật chứng chỉ trong `certifications` array.

### 5. Experience
Cập nhật kinh nghiệm làm việc trong `experience` array.

## 🎨 Tùy chỉnh màu sắc

Màu chính được sử dụng:
- **Cyan**: `#06b6d4` - Primary color
- **Purple**: `#8b5cf6` - Secondary color
- **Green**: `#10b981` - Accent color
- **Black**: `#000000` - Background

Để thay đổi, tìm và thay thế các giá trị màu trong components.

## 🔧 Tính năng nổi bật

### Matrix Rain Effect
- Canvas-based animation
- Tự động responsive
- Performance optimized

### Typing Effect
- Smooth character-by-character animation
- Customizable speed

### Smooth Scrolling
- Navigation tự động scroll
- Smooth behavior

### Glassmorphism UI
- Backdrop blur effects
- Border glows
- Hover animations

### Progress Bars
- Animated skill bars
- Glowing effects
- Customizable levels

## 📝 Ghi chú

- Thay avatar bằng ảnh của bạn tại `/public/avatar.jpg`
- Cập nhật links GitHub, LinkedIn trong `/constants/data.js`
- Contact form hiện tại là mock - bạn có thể tích hợp với backend API
- Tất cả dữ liệu được tập trung tại `/constants/data.js` để dễ quản lý

## 🌟 Features Showcase

### Hero Section
- Typing animation effect
- Floating icons animation
- Social links
- CTA buttons
- Scroll indicator

### Skills Section
- Cybersecurity skills với progress bars
- Programming languages
- Tools & Technologies
- Animated on scroll

### Projects Section
- Featured projects với highlighted cards
- Regular projects grid
- Tags system
- GitHub/Demo links

### Certifications Section
- Verified badges
- Stats counters
- Professional display

### Contact Form
- Full form validation
- Loading state
- Success message
- Smooth UX

## 📱 Responsive Design

- **Mobile**: < 768px
- **Tablet**: 768px - 1024px  
- **Desktop**: > 1024px

Tất cả components đều responsive và tối ưu cho mọi kích thước màn hình.

## 🎯 Tips

1. Thay đổi thông tin trong `/constants/data.js` trước tiên
2. Test trên nhiều devices khác nhau
3. Customize colors để phù hợp với brand của bạn
4. Thêm Google Analytics nếu cần tracking
5. Deploy lên Vercel/Netlify để có HTTPS

## 📄 License

Free to use for personal portfolio. Customize as you need!

---

Made with ❤️ for Cybersecurity Professionals
