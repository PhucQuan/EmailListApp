// 📝 THÔNG TIN CÁ NHÂN - Dễ dàng chỉnh sửa tại đây
export const personalInfo = {
  name: "Trần Hoàng Phúc Quân",
  title: "Cybersecurity | Pentest",
  tagline: "Penetration Tester & Security Researcher",
  bio: "Chuyên gia bảo mật với đam mê tìm kiếm và khai thác lỗ hổng. Có kinh nghiệm trong Web Penetration Testing, Bug Bounty và Red Team Operations. Luôn cập nhật các kỹ thuật tấn công mới nhất để bảo vệ hệ thống tốt hơn.",
  avatar: "/avatar.jpg", // Thay bằng đường dẫn ảnh của bạn
  email: "phucquan.cyber@gmail.com",
  phone: "+84 xxx xxx xxx",
  location: "Việt Nam",
  social: {
    github: "https://github.com/phucquan",
    linkedin: "https://linkedin.com/in/phucquan",
    twitter: "https://twitter.com/phucquan",
    hackerone: "https://hackerone.com/phucquan",
    tryhackme: "https://tryhackme.com/p/phucquan",
  }
};

// 🔐 KỸ NĂNG CYBERSECURITY
export const skills = {
  cybersecurity: [
    { name: "Web Penetration Testing", level: 95, icon: "shield" },
    { name: "XSS (Cross-Site Scripting)", level: 90, icon: "bug" },
    { name: "SQL Injection", level: 92, icon: "database" },
    { name: "Burp Suite", level: 88, icon: "tool" },
    { name: "Linux Security", level: 85, icon: "terminal" },
    { name: "OWASP Top 10", level: 93, icon: "list" },
    { name: "Network Security", level: 80, icon: "network" },
    { name: "Vulnerability Assessment", level: 87, icon: "search" },
  ],
  programming: [
    { name: "JavaScript", level: 85, icon: "code" },
    { name: "Python", level: 90, icon: "code" },
    { name: "C++", level: 75, icon: "code" },
    { name: "Java", level: 70, icon: "code" },
    { name: "C#", level: 72, icon: "code" },
    { name: "PHP", level: 80, icon: "code" },
    { name: "Bash/Shell", level: 88, icon: "terminal" },
  ],
  tools: [
    { name: "Git & GitHub", level: 85 },
    { name: "Docker", level: 80 },
    { name: "Metasploit", level: 82 },
    { name: "Nmap", level: 90 },
    { name: "Wireshark", level: 85 },
    { name: "Kali Linux", level: 93 },
  ]
};

// 📁 PROJECTS
export const projects = [
  {
    id: 1,
    title: "Advanced XSS Scanner",
    description: "Tool tự động phát hiện và khai thác các lỗ hổng XSS phức tạp với 50+ payloads. Hỗ trợ DOM-based, Reflected và Stored XSS.",
    tags: ["Python", "Security", "Automation"],
    github: "https://github.com/phucquan/xss-scanner",
    demo: null,
    image: null,
    featured: true
  },
  {
    id: 2,
    title: "SQL Injection Exploitation Framework",
    description: "Framework mạnh mẽ để test và khai thác SQLi với nhiều kỹ thuật: Union-based, Time-based, Boolean-based và Error-based.",
    tags: ["Python", "SQLi", "Pentest"],
    github: "https://github.com/phucquan/sqli-framework",
    demo: null,
    image: null,
    featured: true
  },
  {
    id: 3,
    title: "Vulnerable Web Application",
    description: "Web app cố ý để lại nhiều lỗ hổng bảo mật nhằm mục đích training và học tập. Bao gồm OWASP Top 10.",
    tags: ["PHP", "MySQL", "Educational"],
    github: "https://github.com/phucquan/vuln-webapp",
    demo: null,
    image: null,
    featured: true
  },
  {
    id: 4,
    title: "Network Vulnerability Scanner",
    description: "Tool quét và phân tích lỗ hổng mạng, hỗ trợ port scanning, service detection và vulnerability assessment.",
    tags: ["Python", "Networking", "Nmap"],
    github: "https://github.com/phucquan/network-scanner",
    demo: null,
    image: null,
    featured: false
  },
  {
    id: 5,
    title: "Password Cracking Suite",
    description: "Bộ công cụ crack password với nhiều thuật toán: Dictionary, Brute-force, Hybrid attack. Tối ưu với GPU.",
    tags: ["C++", "CUDA", "Security"],
    github: "https://github.com/phucquan/password-cracker",
    demo: null,
    image: null,
    featured: false
  },
  {
    id: 6,
    title: "Bug Bounty Automation Toolkit",
    description: "Tự động hóa quy trình recon và testing cho bug bounty. Tích hợp nhiều tools phổ biến.",
    tags: ["Bash", "Automation", "Bug Bounty"],
    github: "https://github.com/phucquan/bb-toolkit",
    demo: null,
    image: null,
    featured: false
  }
];

// 🏅 CHỨNG CHỈ
export const certifications = [
  {
    name: "Certified Ethical Hacker (CEH)",
    issuer: "EC-Council",
    date: "2024",
    verified: true,
    icon: "shield-check"
  },
  {
    name: "Offensive Security Certified Professional (OSCP)",
    issuer: "Offensive Security",
    date: "2023",
    verified: true,
    icon: "award"
  },
  {
    name: "CompTIA Security+",
    issuer: "CompTIA",
    date: "2023",
    verified: true,
    icon: "shield"
  },
  {
    name: "CompTIA PenTest+",
    issuer: "CompTIA",
    date: "2024",
    verified: true,
    icon: "bug"
  },
  {
    name: "AWS Certified Cloud Practitioner",
    issuer: "Amazon Web Services",
    date: "2024",
    verified: true,
    icon: "cloud"
  },
  {
    name: "TryHackMe - Top 1% Global",
    issuer: "TryHackMe",
    date: "2024",
    verified: true,
    icon: "trophy"
  },
  {
    name: "Hacker101 CTF",
    issuer: "HackerOne",
    date: "2023",
    verified: true,
    icon: "flag"
  },
  {
    name: "Google Cybersecurity Certificate",
    issuer: "Google",
    date: "2023",
    verified: true,
    icon: "graduation-cap"
  }
];

// 💼 KINH NGHIỆM
export const experience = [
  {
    role: "Senior Penetration Tester",
    company: "Cybersecurity Firm",
    period: "2023 - Present",
    description: "Thực hiện pentest cho các tổ chức lớn, phát hiện và báo cáo lỗ hổng nghiêm trọng. Tham gia Red Team exercises.",
    achievements: [
      "Phát hiện 50+ lỗ hổng critical trong hệ thống enterprise",
      "Lead 5+ penetration testing projects",
      "Training junior pentesters"
    ]
  },
  {
    role: "Bug Bounty Hunter",
    company: "Independent",
    period: "2022 - Present",
    description: "Tìm kiếm lỗ hổng bảo mật cho các chương trình bug bounty trên HackerOne, Bugcrowd.",
    achievements: [
      "Phát hiện 30+ vulnerabilities được verify",
      "Earned $15,000+ in bounties",
      "Hall of Fame: Google, Microsoft, Facebook"
    ]
  },
  {
    role: "Security Researcher",
    company: "Tech Startup",
    period: "2021 - 2023",
    description: "Nghiên cứu các kỹ thuật tấn công mới, phát triển tools security testing, và tư vấn bảo mật.",
    achievements: [
      "Phát triển 3 security tools được cộng đồng sử dụng",
      "Published 5 security research papers",
      "CVE contributor"
    ]
  }
];

// 📊 THÀNH TỰU
export const achievements = {
  bugsFound: "100+",
  projectsCompleted: "50+",
  cvesPublished: "3",
  bountyEarned: "$15K+"
};
