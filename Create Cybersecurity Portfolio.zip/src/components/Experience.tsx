import { motion } from 'motion/react';
import { Briefcase, CheckCircle } from 'lucide-react';
import { experience } from '../constants/data';

export function Experience() {
  return (
    <section id="about" className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500/10 border border-blue-500/30 rounded-lg mb-4">
            <Briefcase className="w-4 h-4 text-blue-400" />
            <span className="text-blue-400">cat ~/experience.log</span>
          </div>
          <h2 className="mb-4">
            <span className="text-blue-400">{'<'}</span>
            Work Experience
            <span className="text-blue-400">{' />'}</span>
          </h2>
          <p className="text-gray-400">
            My journey in cybersecurity and professional experience
          </p>
        </motion.div>

        {/* Timeline */}
        <div className="relative max-w-4xl mx-auto">
          {/* Timeline line */}
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-cyan-500 via-blue-500 to-purple-500" />

          {experience.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              className="relative mb-12 ml-16"
            >
              {/* Timeline dot */}
              <div className="absolute -left-[2.1rem] top-6 w-4 h-4 bg-cyan-400 rounded-full border-4 border-black" />

              {/* Content card */}
              <div className="bg-black/40 backdrop-blur-sm border border-blue-500/20 hover:border-blue-500/50 rounded-lg p-6 transition-all hover:shadow-xl hover:shadow-blue-500/20 group">
                {/* Period badge */}
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-500/10 border border-blue-500/30 rounded-lg mb-4">
                  <span className="text-blue-400 text-sm">{exp.period}</span>
                </div>

                {/* Role and company */}
                <h3 className="mb-2 text-white group-hover:text-blue-400 transition-colors">
                  {exp.role}
                </h3>
                <h4 className="mb-4 text-blue-400">
                  {exp.company}
                </h4>

                {/* Description */}
                <p className="text-gray-400 mb-4">
                  {exp.description}
                </p>

                {/* Achievements */}
                {exp.achievements && exp.achievements.length > 0 && (
                  <div className="space-y-2">
                    {exp.achievements.map((achievement, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                        <span className="text-sm text-gray-400">{achievement}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Hover effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/0 to-blue-500/0 group-hover:from-blue-500/5 group-hover:to-transparent rounded-lg transition-all pointer-events-none" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
