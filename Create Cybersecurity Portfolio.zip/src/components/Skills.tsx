import { motion } from 'motion/react';
import { Shield, Code, Wrench, Terminal, Database, Bug, Network, Search } from 'lucide-react';
import { skills } from '../constants/data';

const iconMap: { [key: string]: any } = {
  shield: Shield,
  code: Code,
  tool: Wrench,
  terminal: Terminal,
  database: Database,
  bug: Bug,
  network: Network,
  search: Search,
  list: Code,
};

export function Skills() {
  return (
    <section id="skills" className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-cyan-500/10 border border-cyan-500/30 rounded-lg mb-4">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span className="text-cyan-400">ls -la ~/skills</span>
          </div>
          <h2 className="mb-4">
            <span className="text-cyan-400">{'<'}</span>
            Skills & Expertise
            <span className="text-cyan-400">{' />'}</span>
          </h2>
          <p className="text-gray-400">
            Arsenal of tools and technologies I use to break and secure systems
          </p>
        </motion.div>

        {/* Cybersecurity Skills */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-16"
        >
          <h3 className="mb-8 text-center">
            <Shield className="inline-block w-6 h-6 mr-2 text-cyan-400" />
            <span className="text-cyan-400">Cybersecurity</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {skills.cybersecurity.map((skill, index) => {
              const IconComponent = iconMap[skill.icon] || Shield;
              return (
                <motion.div
                  key={skill.name}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="group"
                >
                  <div className="bg-black/40 backdrop-blur-sm border border-cyan-500/20 hover:border-cyan-500/50 rounded-lg p-6 transition-all hover:shadow-lg hover:shadow-cyan-500/20">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-cyan-500/10 rounded-lg flex items-center justify-center group-hover:bg-cyan-500/20 transition-colors">
                          <IconComponent className="w-5 h-5 text-cyan-400" />
                        </div>
                        <span className="text-gray-300 group-hover:text-white transition-colors">
                          {skill.name}
                        </span>
                      </div>
                      <span className="text-cyan-400">{skill.level}%</span>
                    </div>
                    <div className="relative h-2 bg-gray-800 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: index * 0.1 }}
                        className="absolute top-0 left-0 h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full"
                        style={{
                          boxShadow: '0 0 10px rgba(6, 182, 212, 0.5)',
                        }}
                      />
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Programming Skills */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-16"
        >
          <h3 className="mb-8 text-center">
            <Code className="inline-block w-6 h-6 mr-2 text-purple-400" />
            <span className="text-purple-400">Programming</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {skills.programming.map((skill, index) => {
              const IconComponent = iconMap[skill.icon] || Code;
              return (
                <motion.div
                  key={skill.name}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="group"
                >
                  <div className="bg-black/40 backdrop-blur-sm border border-purple-500/20 hover:border-purple-500/50 rounded-lg p-6 transition-all hover:shadow-lg hover:shadow-purple-500/20">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-purple-500/10 rounded-lg flex items-center justify-center group-hover:bg-purple-500/20 transition-colors">
                          <IconComponent className="w-5 h-5 text-purple-400" />
                        </div>
                        <span className="text-gray-300 group-hover:text-white transition-colors">
                          {skill.name}
                        </span>
                      </div>
                      <span className="text-purple-400">{skill.level}%</span>
                    </div>
                    <div className="relative h-2 bg-gray-800 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: index * 0.1 }}
                        className="absolute top-0 left-0 h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                        style={{
                          boxShadow: '0 0 10px rgba(168, 85, 247, 0.5)',
                        }}
                      />
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Tools & Technologies */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h3 className="mb-8 text-center">
            <Wrench className="inline-block w-6 h-6 mr-2 text-green-400" />
            <span className="text-green-400">Tools & Technologies</span>
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {skills.tools.map((tool, index) => (
              <motion.div
                key={tool.name}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.05, rotate: 2 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                className="bg-black/40 backdrop-blur-sm border border-green-500/20 hover:border-green-500/50 rounded-lg p-4 text-center transition-all hover:shadow-lg hover:shadow-green-500/20 group"
              >
                <div className="text-green-400 mb-2 group-hover:text-green-300 transition-colors">
                  {tool.name}
                </div>
                <div className="text-xs text-gray-500">{tool.level}%</div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
