import { motion } from 'motion/react';
import { Award, ShieldCheck, Bug, Shield, Cloud, Trophy, Flag, GraduationCap, CheckCircle } from 'lucide-react';
import { certifications } from '../constants/data';

const iconMap: { [key: string]: any } = {
  'shield-check': ShieldCheck,
  award: Award,
  shield: Shield,
  bug: Bug,
  cloud: Cloud,
  trophy: Trophy,
  flag: Flag,
  'graduation-cap': GraduationCap,
};

export function Certifications() {
  return (
    <section id="certifications" className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-500/10 border border-green-500/30 rounded-lg mb-4">
            <Award className="w-4 h-4 text-green-400" />
            <span className="text-green-400">cat ~/certifications.txt</span>
          </div>
          <h2 className="mb-4">
            <span className="text-green-400">{'<'}</span>
            Certifications & Achievements
            <span className="text-green-400">{' />'}</span>
          </h2>
          <p className="text-gray-400">
            Professional certifications and industry recognition
          </p>
        </motion.div>

        {/* Certifications Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {certifications.map((cert, index) => {
            const IconComponent = iconMap[cert.icon] || Award;
            return (
              <motion.div
                key={cert.name}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.05, y: -5 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="group relative"
              >
                <div className="bg-black/40 backdrop-blur-sm border border-green-500/20 hover:border-green-500/50 rounded-lg p-6 transition-all hover:shadow-xl hover:shadow-green-500/20 h-full flex flex-col">
                  {/* Verified badge */}
                  {cert.verified && (
                    <div className="absolute top-4 right-4">
                      <CheckCircle className="w-5 h-5 text-green-400 fill-green-400/20" />
                    </div>
                  )}

                  {/* Icon */}
                  <div className="w-16 h-16 bg-green-500/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-green-500/20 transition-colors">
                    <IconComponent className="w-8 h-8 text-green-400" />
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <h4 className="mb-2 text-white group-hover:text-green-400 transition-colors">
                      {cert.name}
                    </h4>
                    <p className="text-sm text-gray-400 mb-2">
                      {cert.issuer}
                    </p>
                    <p className="text-xs text-gray-500">
                      {cert.date}
                    </p>
                  </div>

                  {/* Glowing effect on hover */}
                  <div className="absolute inset-0 bg-gradient-to-br from-green-500/0 to-green-500/0 group-hover:from-green-500/5 group-hover:to-transparent rounded-lg transition-all pointer-events-none" />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Stats Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6"
        >
          {[
            { label: 'Bugs Found', value: '100+', icon: Bug },
            { label: 'Projects', value: '50+', icon: Trophy },
            { label: 'CVEs', value: '3', icon: ShieldCheck },
            { label: 'Bounty Earned', value: '$15K+', icon: Award },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="text-center"
            >
              <div className="bg-black/40 backdrop-blur-sm border border-cyan-500/20 rounded-lg p-6 hover:border-cyan-500/50 transition-all hover:shadow-lg hover:shadow-cyan-500/20">
                <stat.icon className="w-8 h-8 text-cyan-400 mx-auto mb-3" />
                <div className="text-3xl text-white mb-1">{stat.value}</div>
                <div className="text-sm text-gray-400">{stat.label}</div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
