
  # Create Cybersecurity Portfolio

  This is a code bundle for Create Cybersecurity Portfolio. The original project is available at https://www.figma.com/design/aubE0PyOzGZOuQroUvbR7Z/Create-Cybersecurity-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  