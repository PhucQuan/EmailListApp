export const styles = `
:root {
  --primary: #be185d;
  --primary-light: #fce7f3;
  --secondary: #0f766e;
  --bg: #fff1f2;
  --card: #ffffff;
  --text: #374151;
  --text-light: #6b7280;
  --danger: #ef4444;
  --warning: #f59e0b;
  --success: #10b981;
}

* { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
body { margin: 0; padding: 0; background: var(--bg); color: var(--text); min-height: 100vh; }
.container { max-width: 800px; margin: 0 auto; padding: 20px; }
.header { text-align: center; margin-bottom: 30px; }
.header h1 { color: var(--primary); font-size: 2rem; margin-bottom: 0.5rem; }
.header p { color: var(--text-light); }
.card { background: var(--card); border-radius: 16px; padding: 24px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); margin-bottom: 20px; }
.upload-area { border: 2px dashed var(--primary); border-radius: 16px; padding: 40px; text-align: center; cursor: pointer; background: var(--primary-light); transition: all 0.2s; }
.upload-area:hover { background: #fbcfe8; }
.btn { background: var(--primary); color: white; border: none; padding: 12px 24px; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 1rem; transition: opacity 0.2s; display: inline-flex; align-items: center; gap: 8px; }
.btn:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-secondary { background: white; color: var(--primary); border: 2px solid var(--primary); }
.preview-img { max-width: 100%; max-height: 300px; border-radius: 8px; margin: 20px auto; display: block; object-fit: contain; }
.badge { padding: 4px 12px; border-radius: 999px; font-size: 0.85rem; font-weight: 600; display: inline-block; }
.badge-safe { background: #d1fae5; color: #065f46; }
.badge-caution { background: #fef3c7; color: #92400e; }
.badge-risky { background: #fee2e2; color: #991b1b; }
.section-title { font-size: 1.25rem; font-weight: 700; color: var(--primary); margin: 24px 0 16px; display: flex; align-items: center; gap: 8px; }
.ingredient-list { display: grid; gap: 12px; }
.ingredient-item { border: 1px solid #e5e7eb; border-radius: 8px; padding: 12px; display: flex; justify-content: space-between; align-items: center; background: #fff; }
.ingredient-info { flex: 1; }
.ingredient-name { font-weight: 600; display: block; margin-bottom: 4px; }
.ingredient-func { font-size: 0.9rem; color: var(--text-light); }
.rating-circle { width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 0.9rem; margin-left: 12px; flex-shrink: 0; }
.rating-low { background: #d1fae5; color: #065f46; }
.rating-med { background: #fef3c7; color: #92400e; }
.rating-high { background: #fee2e2; color: #991b1b; }
.tags { display: flex; flex-wrap: wrap; gap: 8px; }
.tag { background: #f3f4f6; padding: 6px 12px; border-radius: 6px; font-size: 0.9rem; color: #4b5563; }
.loading-spinner { border: 4px solid #f3f3f3; border-top: 4px solid var(--primary); border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin: 20px auto; }
@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
.camera-modal { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: black; z-index: 1000; display: flex; flex-direction: column; }
.camera-view { flex: 1; width: 100%; object-fit: cover; }
.camera-controls { padding: 20px; display: flex; justify-content: space-around; background: rgba(0,0,0,0.8); }
.warning-box { background: #fff5f5; border-left: 4px solid var(--danger); padding: 12px; margin-bottom: 12px; border-radius: 4px; }
.pros-cons { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
@media (max-width: 600px) { .pros-cons { grid-template-columns: 1fr; } }
`;