import React, { useState, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { styles } from './styles';
import { analyzeImageWithGemini } from './api';
import { CameraModal } from './Camera';
import { ResultDisplay } from './ResultDisplay';
import { AnalysisResult } from './types';

// Main App Component
function App() {
  const [image, setImage] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (evt) => {
        setImage(evt.target?.result as string);
        setResult(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!image) return;
    setAnalyzing(true);
    setError(null);
    try {
      const base64Data = image.split(',')[1];
      const data = await analyzeImageWithGemini(base64Data);
      setResult(data);
    } catch (err: any) {
      console.error(err);
      setError("Có lỗi xảy ra: " + (err.message || "Lỗi không xác định"));
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <>
      <style>{styles}</style>
      
      {showCamera && (
        <CameraModal 
          onCapture={(img) => { setImage(img); setShowCamera(false); setResult(null); setError(null); }}
          onClose={() => setShowCamera(false)}
          onError={(msg) => { setError(msg); setShowCamera(false); }}
        />
      )}

      <div className="container">
        <header className="header">
          <h1>Cosmetic Analyzer</h1>
          <p>Chuyên gia phân tích thành phần mỹ phẩm AI</p>
        </header>

        <div className="card">
          {!image ? (
            <div className="upload-area" onClick={() => fileInputRef.current?.click()}>
              <div style={{ marginBottom: 15 }}>
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: 'var(--primary)'}}>
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                  <polyline points="17 8 12 3 7 8"></polyline>
                  <line x1="12" y1="3" x2="12" y2="15"></line>
                </svg>
              </div>
              <h3>Tải ảnh sản phẩm lên</h3>
              <p style={{color: 'var(--text-light)'}}>hoặc chụp trực tiếp từ camera</p>
              
              <div style={{ marginTop: 20, display: 'flex', gap: 10, justifyContent: 'center' }}>
                <button className="btn" onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}>
                  Chọn ảnh
                </button>
                <button className="btn btn-secondary" onClick={(e) => { e.stopPropagation(); setShowCamera(true); }}>
                  Mở Camera
                </button>
              </div>
              <input type="file" accept="image/*" ref={fileInputRef} onChange={handleFileUpload} hidden />
            </div>
          ) : (
            <div>
              <img src={image} alt="Preview" className="preview-img" />
              <div style={{ display: 'flex', justifyContent: 'center', gap: 10 }}>
                <button className="btn btn-secondary" onClick={() => { setImage(null); setResult(null); }}>
                  Chọn lại
                </button>
                {!result && !analyzing && (
                  <button className="btn" onClick={handleAnalyze}>
                    Phân tích ngay
                  </button>
                )}
              </div>
            </div>
          )}

          {error && (
            <div style={{ marginTop: 20, color: 'var(--danger)', textAlign: 'center' }}>
              ⚠️ {error}
            </div>
          )}

          {analyzing && (
            <div style={{ textAlign: 'center', padding: 20 }}>
              <div className="loading-spinner"></div>
              <p>Đang đọc bảng thành phần...</p>
            </div>
          )}
        </div>

        {result && <ResultDisplay result={result} />}
      </div>
    </>
  );
}

const root = createRoot(document.getElementById('app')!);
root.render(<App />);