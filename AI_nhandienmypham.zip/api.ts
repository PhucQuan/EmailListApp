import { GoogleGenAI } from "@google/genai";
import { IngredientSchema, AnalysisResult } from "./types";

const SYSTEM_PROMPT = `Bạn là chuyên gia phân tích thành phần mỹ phẩm và dược mỹ phẩm. Nhiệm vụ của bạn:
1. TRÍCH XUẤT THÀNH PHẦN: Đọc và liệt kê TẤT CẢ thành phần từ ảnh mặt sau sản phẩm, giữ nguyên tên tiếng Anh, sắp xếp theo thứ tự.
2. PHÂN TÍCH CHI TIẾT:
   - MỨC ĐỘ GÂY MỤN (Comedogenic Rating): 0=An toàn, 1-2=Nguy cơ thấp, 3-5=Nguy cơ cao.
   - CÔNG DỤNG CHÍNH: Giải thích ngắn gọn tiếng Việt.
   - CẢNH BÁO TƯƠNG TÁC: Retinol, AHA/BHA, Vit C, BPO, Niacinamide.
   - ĐÁNH GIÁ TỔNG QUAN: Loại da phù hợp, điểm mạnh, lưu ý.
3. OUTPUT JSON format as requested.
4. QUY TẮC: Ưu tiên an toàn, giải thích tiếng Việt đơn giản.`;

export async function analyzeImageWithGemini(base64Data: string): Promise<AnalysisResult> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: [
      {
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: base64Data } },
          { text: "Hãy phân tích bảng thành phần trong ảnh này." }
        ]
      }
    ],
    config: {
      systemInstruction: SYSTEM_PROMPT,
      responseMimeType: "application/json",
      responseSchema: IngredientSchema,
    }
  });

  const jsonText = response.text;
  if (!jsonText) {
    throw new Error("Không nhận được dữ liệu phản hồi.");
  }
  return JSON.parse(jsonText);
}