import { Type, Schema } from "@google/genai";

export interface Ingredient {
  name: string;
  comedogenic_rating: number;
  function: string;
  is_risky: boolean;
}

export interface Warning {
  type: string;
  message: string;
}

export interface AnalysisResult {
  product_name?: string;
  ingredients: Ingredient[];
  key_ingredients: string[];
  warnings: Warning[];
  suitable_for: string[];
  pros: string[];
  cons: string[];
  overall_safety: 'safe' | 'caution' | 'risky';
}

export const IngredientSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    product_name: { type: Type.STRING, description: "Tên sản phẩm phát hiện được" },
    ingredients: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          comedogenic_rating: { type: Type.INTEGER, description: "0-5" },
          function: { type: Type.STRING, description: "Công dụng bằng tiếng Việt" },
          is_risky: { type: Type.BOOLEAN },
        },
        required: ["name", "comedogenic_rating", "function", "is_risky"],
      },
    },
    key_ingredients: { type: Type.ARRAY, items: { type: Type.STRING } },
    warnings: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          type: { type: Type.STRING },
          message: { type: Type.STRING },
        },
      },
    },
    suitable_for: { type: Type.ARRAY, items: { type: Type.STRING } },
    pros: { type: Type.ARRAY, items: { type: Type.STRING } },
    cons: { type: Type.ARRAY, items: { type: Type.STRING } },
    overall_safety: { type: Type.STRING, enum: ["safe", "caution", "risky"] },
  },
  required: ["ingredients", "overall_safety"],
};