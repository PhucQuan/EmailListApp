import React from 'react';
import { AnalysisResult } from './types';

const SafetyBadge = ({ safety }: { safety: string }) => {
  switch (safety) {
    case 'safe': return <span className="badge badge-safe">An toàn</span>;
    case 'caution': return <span className="badge badge-caution">Cẩn trọng</span>;
    case 'risky': return <span className="badge badge-risky">Nguy cơ cao</span>;
    default: return <span className="badge">{safety}</span>;
  }
};

const RatingCircle = ({ rating }: { rating: number }) => {
  let className = 'rating-low';
  if (rating > 3) className = 'rating-high';
  else if (rating > 2) className = 'rating-med';
  
  return (
    <div className={`rating-circle ${className}`} title="Mức độ gây mụn (0-5)">
      {rating}
    </div>
  );
};

export const ResultDisplay: React.FC<{ result: AnalysisResult }> = ({ result }) => {
  return (
    <div className="analysis-result">
      {/* Overview Card */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h2 style={{ margin: 0, color: 'var(--text)' }}>
            {result.product_name || "Kết quả phân tích"}
          </h2>
          <SafetyBadge safety={result.overall_safety} />
        </div>

        <div className="section-title">Phù hợp cho</div>
        <div className="tags">
          {result.suitable_for?.map((skin, idx) => (
            <span key={idx} className="tag">{skin}</span>
          ))}
        </div>

        <div className="pros-cons" style={{ marginTop: 20 }}>
          <div>
            <h4 style={{ color: 'var(--success)' }}>Ưu điểm</h4>
            <ul style={{ paddingLeft: 20 }}>
              {result.pros?.map((pro, idx) => <li key={idx}>{pro}</li>)}
            </ul>
          </div>
          <div>
            <h4 style={{ color: 'var(--text-light)' }}>Nhược điểm</h4>
            <ul style={{ paddingLeft: 20 }}>
              {result.cons?.map((con, idx) => <li key={idx}>{con}</li>)}
            </ul>
          </div>
        </div>
      </div>

      {/* Warnings */}
      {result.warnings && result.warnings.length > 0 && (
        <div className="card" style={{ borderLeft: '4px solid var(--warning)' }}>
          <div className="section-title" style={{ color: 'var(--warning)', marginTop: 0 }}>
             ⚠️ Cảnh báo tương tác
          </div>
          {result.warnings.map((w, idx) => (
            <div key={idx} className="warning-box">
              <strong>{w.type}:</strong> {w.message}
            </div>
          ))}
        </div>
      )}

      {/* Key Ingredients */}
      <div className="card">
        <div className="section-title">Thành phần nổi bật</div>
        <div className="tags">
          {result.key_ingredients?.map((ing, idx) => (
            <span key={idx} className="tag" style={{ background: 'var(--primary-light)', color: 'var(--primary)', fontWeight: 600 }}>
              {ing}
            </span>
          ))}
        </div>
      </div>

      {/* Detailed List */}
      <div className="card">
        <div className="section-title">
          Chi tiết thành phần ({result.ingredients?.length})
        </div>
        <div className="ingredient-list">
          {result.ingredients?.map((ing, idx) => (
            <div key={idx} className="ingredient-item">
              <div className="ingredient-info">
                <span className="ingredient-name" style={{ color: ing.is_risky ? 'var(--danger)' : 'inherit' }}>
                  {ing.name} {ing.is_risky && '⚠️'}
                </span>
                <span className="ingredient-func">{ing.function}</span>
              </div>
              <RatingCircle rating={ing.comedogenic_rating} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};