import React, { useRef, useEffect } from 'react';

interface CameraModalProps {
  onCapture: (imageData: string) => void;
  onClose: () => void;
  onError: (error: string) => void;
}

export const CameraModal: React.FC<CameraModalProps> = ({ onCapture, onClose, onError }) => {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;
    const startCamera = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: 'environment' } 
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
      } catch (err) {
        onError("Không thể truy cập camera.");
        onClose();
      }
    };
    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [onClose, onError]);

  const capture = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(videoRef.current, 0, 0);
      const dataUrl = canvas.toDataURL('image/jpeg');
      onCapture(dataUrl);
    }
  };

  return (
    <div className="camera-modal">
      <video ref={videoRef} className="camera-view" playsInline autoPlay muted />
      <div className="camera-controls">
        <button className="btn btn-secondary" onClick={onClose}>Hủy</button>
        <button className="btn" onClick={capture}>Chụp ảnh</button>
      </div>
    </div>
  );
};