# Design Guidelines: Cybersecurity Portfolio Website

## Design Approach
**Reference-Based: Modern Tech Portfolio + Cyberpunk Aesthetic**
- Inspired by Linear's precision and Stripe's restraint, elevated with cyberpunk edge
- Terminal-inspired UI elements with neon accents against dark backgrounds
- Clean, professional structure that appeals to recruiters while showcasing technical prowess

## Layout System
**Tailwind Spacing Primitives**: Use units of 2, 4, 6, 8, 12, and 16
- Container: max-w-6xl for content sections, max-w-4xl for text-heavy areas
- Section padding: py-16 (mobile), py-24 (desktop)
- Component spacing: gap-8 for grids, space-y-6 for vertical content

## Typography Hierarchy
**Font Stack**:
- Primary: JetBrains Mono (headings, code elements) - monospace for cyberpunk feel
- Secondary: Inter (body text) - clean readability

**Hierarchy**:
- Hero headline: text-5xl/text-6xl, font-bold, tracking-tight, monospace
- Section headings: text-3xl/text-4xl, font-semibold, uppercase tracking-wider
- Subsection titles: text-xl, font-medium
- Body text: text-base, leading-relaxed
- Code/technical: text-sm, font-mono

## Core Components

### Navigation
Minimal top nav with glassmorphism effect (backdrop-blur)
- Logo with glitch effect on hover
- Smooth scroll anchor links (Skills, Projects, Experience, Contact)
- Resume download button (border with glow effect)

### Hero Section
Full-viewport height (100vh) with animated grid pattern background
- Large headline with typing animation effect displaying role/specialty
- Subtitle with brief expertise statement
- Terminal-style prompt indicator (blinking cursor)
- Scroll indicator with downward chevron animation
- No large background image - use animated grid/matrix pattern instead

### Skills Section
Three-column grid showcasing expertise categories
- Cybersecurity: Penetration testing, vulnerability assessment, threat analysis tools
- Programming: Python, JavaScript, Bash scripting languages
- Tools: Wireshark, Metasploit, Burp Suite, Kali Linux icons with Heroicons
- Each skill card with icon, title, proficiency indicator (horizontal bars)
- Hover effect: Card border glow intensifies

### Projects Section (GitHub Integration)
Two-column grid (desktop), single column (mobile)
- Project cards with terminal window aesthetic (mock window chrome at top)
- Project thumbnail/screenshot with rounded-lg
- Title + tech stack badges (small pills)
- Brief description + metrics (stars, forks if applicable)
- "View Project" + "Live Demo" links with arrow icons
- Stagger animation on scroll reveal

### Certificates Section
Horizontal scrollable carousel on mobile, 3-column grid on desktop
- Certificate card with issuing organization logo
- Certification name + credential ID
- Issue date + expiration (if applicable)
- Verify link with external icon
- Cards with subtle border and hover lift

### Experience Timeline
Vertical timeline with alternating left/right layout (desktop), left-aligned (mobile)
- Timeline line with glowing nodes at each position
- Position title + company + duration
- Key achievements in bullet points
- Tech stack used (icon badges)
- Connector animations on scroll

### Contact Section
Centered single-column form with max-w-2xl
- Form fields: Name, Email, Subject, Message (textarea)
- Input styling: Border with glow on focus, minimal padding
- Submit button with loading state animation
- Social links below (LinkedIn, GitHub, Twitter) with icons
- Email address display with copy-to-clipboard functionality

### Footer
Minimal single row: Copyright + "Built with [technologies]" + Back to top link

## Images Strategy

**No large hero background image** - use animated pattern/grid instead

**Required Images**:
1. **Project Screenshots**: Landscape format (800x450) showing application interfaces or terminal outputs
2. **Certificate Logos**: Organization logos (150x150) for credential verification
3. **Favicon**: Custom cybersecurity-themed icon

**Image Treatment**:
- Rounded corners: rounded-lg consistently
- Border glow on hover
- Loading states: Skeleton loaders with shimmer

## Animations & Interactions

**Strategic Animation Points** (minimal use):
1. Hero typing effect (one-time on load)
2. Scroll-triggered fade-up for sections (stagger children)
3. Timeline node reveal on scroll
4. Skill bar fill animations
5. Subtle card hover lifts (translate-y-1)

**Performance**: Use CSS transforms only, avoid layout thrashing, prefers-reduced-motion support

## Accessibility
- High contrast ratios for text readability
- Focus indicators with visible outlines
- Keyboard navigation for all interactive elements
- ARIA labels for icon-only buttons
- Form validation with clear error messaging

## Responsive Breakpoints
- Mobile-first implementation
- Key breakpoints: md (768px), lg (1024px)
- Timeline switches to left-aligned on mobile
- Navigation collapses to hamburger menu below md
- Grid columns reduce gracefully: 3→2→1

This design creates a technically sophisticated, visually distinctive portfolio that demonstrates both design sensibility and cybersecurity expertise, appealing to technical recruiters while maintaining professional credibility.