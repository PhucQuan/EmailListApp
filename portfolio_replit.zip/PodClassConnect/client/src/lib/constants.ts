export const personalInfo = {
  name: "Trần Hoàng Phúc Quân",
  title: "Cybersecurity | Pentest",
  bio: "Chuyên gia bảo mật mạng với niềm đam mê phát hiện và khắc phục các lỗ hổng bảo mật. Tập trung vào penetration testing, đánh giá bảo mật web applications và phân tích mối đe dọa để bảo vệ hệ thống khỏi các cuộc tấn công.",
  avatar: "/path-to-avatar.png",
  email: "phucquan@example.com",
  github: "https://github.com/phucquan",
  linkedin: "https://linkedin.com/in/phucquan",
  resumeUrl: "/resume.pdf"
};

export const skills = {
  cybersecurity: [
    { name: "Web Penetration Testing", proficiency: 90 },
    { name: "XSS (Cross-Site Scripting)", proficiency: 85 },
    { name: "SQL Injection", proficiency: 88 },
    { name: "Burp Suite", proficiency: 92 },
    { name: "Linux System Security", proficiency: 85 },
    { name: "OWASP Top 10", proficiency: 90 }
  ],
  programming: [
    { name: "JavaScript", proficiency: 85 },
    { name: "Python", proficiency: 88 },
    { name: "C++", proficiency: 75 },
    { name: "Java", proficiency: 70 },
    { name: "C#", proficiency: 72 },
    { name: "PHP", proficiency: 80 }
  ],
  tools: [
    { name: "Git & GitHub", proficiency: 90 },
    { name: "Docker", proficiency: 82 },
    { name: "Networking (TCP/IP)", proficiency: 85 },
    { name: "Wireshark", proficiency: 80 },
    { name: "Metasploit", proficiency: 78 },
    { name: "Kali Linux", proficiency: 88 }
  ]
};

export const projects = [
  {
    id: 1,
    title: "Vulnerability Scanner",
    description: "Công cụ quét lỗ hổng bảo mật tự động cho web applications, phát hiện các lỗi XSS, SQL Injection và CSRF.",
    techStack: ["Python", "Flask", "BeautifulSoup", "SQLMap"],
    githubUrl: "https://github.com/phucquan/vuln-scanner",
    liveUrl: "",
    stars: 45,
    forks: 12
  },
  {
    id: 2,
    title: "CTF Toolkit",
    description: "Bộ công cụ hỗ trợ giải Capture The Flag challenges, bao gồm crypto, forensics, và web exploitation tools.",
    techStack: ["Python", "JavaScript", "Bash"],
    githubUrl: "https://github.com/phucquan/ctf-toolkit",
    liveUrl: "",
    stars: 38,
    forks: 9
  },
  {
    id: 3,
    title: "Network Traffic Analyzer",
    description: "Phân tích network traffic để phát hiện các hoạt động bất thường và các cuộc tấn công tiềm ẩn.",
    techStack: ["Python", "Scapy", "Wireshark"],
    githubUrl: "https://github.com/phucquan/network-analyzer",
    liveUrl: "",
    stars: 52,
    forks: 15
  },
  {
    id: 4,
    title: "Secure Password Manager",
    description: "Ứng dụng quản lý mật khẩu an toàn với mã hóa AES-256 và multi-factor authentication.",
    techStack: ["React", "Node.js", "MongoDB", "Crypto"],
    githubUrl: "https://github.com/phucquan/password-manager",
    liveUrl: "https://secure-pass.example.com",
    stars: 67,
    forks: 18
  }
];

export const certificates = [
  {
    id: 1,
    name: "Certified Ethical Hacker (CEH)",
    issuer: "EC-Council",
    date: "2024",
    credentialId: "ECC1234567890",
    verifyUrl: "https://aspen.eccouncil.org/Verify"
  },
  {
    id: 2,
    name: "Offensive Security Certified Professional (OSCP)",
    issuer: "Offensive Security",
    date: "2023",
    credentialId: "OS-12345",
    verifyUrl: "https://www.offensive-security.com/verify/"
  },
  {
    id: 3,
    name: "CompTIA Security+",
    issuer: "CompTIA",
    date: "2023",
    credentialId: "COMP001234567",
    verifyUrl: "https://www.certmetrics.com/comptia/"
  },
  {
    id: 4,
    name: "CompTIA PenTest+",
    issuer: "CompTIA",
    date: "2024",
    credentialId: "COMP001234568",
    verifyUrl: "https://www.certmetrics.com/comptia/"
  },
  {
    id: 5,
    name: "AWS Certified Cloud Practitioner",
    issuer: "Amazon Web Services",
    date: "2023",
    credentialId: "AWS-12345678",
    verifyUrl: "https://www.credly.com/badges/"
  },
  {
    id: 6,
    name: "TryHackMe Top 1%",
    issuer: "TryHackMe",
    date: "2024",
    credentialId: "",
    verifyUrl: "https://tryhackme.com/p/phucquan"
  },
  {
    id: 7,
    name: "Hacker101 CTF",
    issuer: "HackerOne",
    date: "2023",
    credentialId: "",
    verifyUrl: "https://ctf.hacker101.com/"
  },
  {
    id: 8,
    name: "Google Cybersecurity Certificate",
    issuer: "Google via Coursera",
    date: "2023",
    credentialId: "GOOGLE123456",
    verifyUrl: "https://www.coursera.org/account/accomplishments/"
  }
];

export const experience = [
  {
    id: 1,
    position: "Security Analyst",
    company: "CyberShield Solutions",
    duration: "2023 - Present",
    location: "Ho Chi Minh City, Vietnam",
    responsibilities: [
      "Thực hiện penetration testing cho web applications và mobile apps",
      "Phát hiện và báo cáo hơn 50 lỗ hổng bảo mật nghiêm trọng",
      "Tư vấn giải pháp bảo mật cho khách hàng doanh nghiệp",
      "Phát triển automation tools để tăng hiệu quả testing"
    ],
    techStack: ["Burp Suite", "OWASP ZAP", "Python", "Kali Linux"]
  },
  {
    id: 2,
    position: "Junior Penetration Tester",
    company: "SecureIT Vietnam",
    duration: "2022 - 2023",
    location: "Ho Chi Minh City, Vietnam",
    responsibilities: [
      "Hỗ trợ team thực hiện vulnerability assessments",
      "Tham gia red team exercises và phân tích security incidents",
      "Viết báo cáo kỹ thuật chi tiết về các lỗ hổng phát hiện",
      "Nghiên cứu các kỹ thuật tấn công mới và cập nhật knowledge base"
    ],
    techStack: ["Metasploit", "Nmap", "Wireshark", "Bash Scripting"]
  },
  {
    id: 3,
    position: "Cybersecurity Intern",
    company: "VietnamSec Lab",
    duration: "2021 - 2022",
    location: "Hanoi, Vietnam",
    responsibilities: [
      "Học tập và thực hành các kỹ thuật penetration testing cơ bản",
      "Tham gia giải CTF challenges và security workshops",
      "Hỗ trợ setup và maintain security testing infrastructure",
      "Tài liệu hóa findings và best practices"
    ],
    techStack: ["Linux", "Python", "SQL", "Web Security"]
  }
];

export const socialLinks = {
  github: "https://github.com/phucquan",
  linkedin: "https://linkedin.com/in/phucquan",
  email: "phucquan@example.com",
  twitter: "https://twitter.com/phucquan"
};
