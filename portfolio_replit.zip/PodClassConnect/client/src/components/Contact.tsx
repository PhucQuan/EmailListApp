import { useState } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Github, Linkedin, Mail, Twitter, Send, MessageSquare } from "lucide-react";
import { socialLinks } from "@/lib/constants";
import { useToast } from "@/hooks/use-toast";

const socialIcons = [
  { icon: Github, href: socialLinks.github, label: "GitHub", testId: "link-github", color: "hover:text-foreground" },
  { icon: Linkedin, href: socialLinks.linkedin, label: "LinkedIn", testId: "link-linkedin", color: "hover:text-primary" },
  { icon: Twitter, href: socialLinks.twitter, label: "Twitter", testId: "link-twitter", color: "hover:text-accent" },
  { icon: Mail, href: `mailto:${socialLinks.email}`, label: "Email", testId: "link-email", color: "hover:text-chart-3" }
];

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      console.log("Form submitted:", formData);
      toast({
        title: "Message sent!",
        description: "Thank you for reaching out. I'll get back to you soon."
      });
      setFormData({ name: "", email: "", subject: "", message: "" });
      setIsSubmitting(false);
    }, 1500);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <section id="contact" className="py-20 sm:py-24 relative overflow-hidden" data-testid="section-contact">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-primary rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 mb-4">
            <MessageSquare className="w-6 h-6 text-primary" />
            <h2 className="text-3xl sm:text-4xl font-bold font-mono uppercase tracking-widest bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent"
                data-testid="text-contact-title">
              Get In Touch
            </h2>
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Có câu hỏi hoặc muốn hợp tác? Hãy liên hệ với tôi!
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
        >
          <Card className="p-6 sm:p-8 mb-8 border-border/50 bg-gradient-to-br from-card/80 to-background/50 backdrop-blur-sm hover-glow-primary">
            <form onSubmit={handleSubmit} className="space-y-6" data-testid="form-contact">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium font-mono mb-2 text-muted-foreground">
                    Name
                  </label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    placeholder="Your name"
                    className="font-mono border-border/50 focus:border-primary focus:ring-primary/20"
                    data-testid="input-name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium font-mono mb-2 text-muted-foreground">
                    Email
                  </label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    placeholder="your.email@example.com"
                    className="font-mono border-border/50 focus:border-primary focus:ring-primary/20"
                    data-testid="input-email"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="subject" className="block text-sm font-medium font-mono mb-2 text-muted-foreground">
                  Subject
                </label>
                <Input
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  placeholder="What's this about?"
                  className="font-mono border-border/50 focus:border-primary focus:ring-primary/20"
                  data-testid="input-subject"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium font-mono mb-2 text-muted-foreground">
                  Message
                </label>
                <Textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  placeholder="Your message..."
                  rows={6}
                  className="font-mono border-border/50 focus:border-primary focus:ring-primary/20 resize-none"
                  data-testid="textarea-message"
                />
              </div>

              <Button
                type="submit"
                className="w-full font-mono hover-glow-primary"
                disabled={isSubmitting}
                data-testid="button-submit"
              >
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <motion.span
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      className="inline-block"
                    >
                      ⟳
                    </motion.span>
                    Sending...
                  </span>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Send Message
                  </>
                )}
              </Button>
            </form>
          </Card>

          {/* Social links with enhanced styling */}
          <div className="flex justify-center gap-4">
            {socialIcons.map((social) => (
              <motion.a
                key={social.label}
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.1, y: -2 }}
                whileTap={{ scale: 0.95 }}
                className={`p-3 rounded-lg bg-card border border-border/50 hover-elevate transition-colors ${social.color} group`}
                aria-label={social.label}
                data-testid={social.testId}
              >
                <social.icon className="w-5 h-5" />
              </motion.a>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
