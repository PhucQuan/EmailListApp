import Certificates from "../Certificates";

export default function CertificatesExample() {
  return (
    <div className="bg-background">
      <Certificates />
    </div>
  );
}
