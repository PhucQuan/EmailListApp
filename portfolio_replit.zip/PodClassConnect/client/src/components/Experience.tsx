import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Briefcase, MapPin, Calendar } from "lucide-react";
import { experience } from "@/lib/constants";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.25
    }
  }
};

const item = {
  hidden: { opacity: 0, x: -30 },
  show: { opacity: 1, x: 0, transition: { duration: 0.5 } }
};

export default function Experience() {
  return (
    <section id="experience" className="py-20 sm:py-24 bg-card/20 relative overflow-hidden" data-testid="section-experience">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-accent rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 mb-4">
            <Briefcase className="w-6 h-6 text-accent" />
            <h2 className="text-3xl sm:text-4xl font-bold font-mono uppercase tracking-widest bg-gradient-to-r from-accent via-primary to-accent bg-clip-text text-transparent"
                data-testid="text-experience-title">
              Work Experience
            </h2>
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Lộ trình sự nghiệp và kinh nghiệm cybersecurity
          </p>
        </motion.div>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="relative"
        >
          {/* Enhanced timeline line with glow */}
          <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary via-accent to-primary opacity-50"></div>
          <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary via-accent to-primary blur-sm"></div>

          {experience.map((exp, idx) => (
            <motion.div
              key={exp.id}
              variants={item}
              className={`relative mb-12 ${
                idx % 2 === 0 ? "md:pr-8 md:text-right" : "md:pl-8 md:ml-auto md:text-left"
              }`}
              data-testid={`card-experience-${exp.id}`}
            >
              {/* Enhanced timeline node with multiple glow layers */}
              <div
                className={`absolute left-0 md:left-1/2 top-8 w-5 h-5 rounded-full bg-gradient-to-br from-primary to-accent border-4 border-background transform -translate-x-2 md:-translate-x-2.5 z-10`}
                style={{ 
                  boxShadow: `
                    0 0 20px hsl(var(--primary) / 0.8),
                    0 0 40px hsl(var(--primary) / 0.4),
                    0 0 60px hsl(var(--accent) / 0.2)
                  `
                }}
              >
                <motion.div
                  className="absolute inset-0 rounded-full bg-gradient-to-br from-primary to-accent"
                  animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              </div>

              <Card className="p-6 ml-8 md:ml-0 md:w-[calc(50%-2rem)] hover-elevate hover-glow-accent border-border/50 bg-gradient-to-br from-card/80 to-background/50 backdrop-blur-sm">
                <div className="flex items-start gap-3 mb-4">
                  <div className="p-2 rounded-lg bg-accent/10 text-accent border border-accent/20">
                    <Briefcase className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-xl font-semibold font-mono text-primary mb-2" data-testid={`text-position-${exp.id}`}>
                      {exp.position}
                    </h3>
                    <p className="font-medium mb-2" data-testid={`text-company-${exp.id}`}>{exp.company}</p>
                    <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1.5 font-mono" data-testid={`text-duration-${exp.id}`}>
                        <Calendar className="w-3.5 h-3.5" />
                        {exp.duration}
                      </span>
                      <span className="flex items-center gap-1.5 font-mono" data-testid={`text-location-${exp.id}`}>
                        <MapPin className="w-3.5 h-3.5" />
                        {exp.location}
                      </span>
                    </div>
                  </div>
                </div>

                <ul className="space-y-2 mb-4 text-sm text-muted-foreground">
                  {exp.responsibilities.map((resp, respIdx) => (
                    <li key={respIdx} className="flex gap-2 items-start" data-testid={`text-responsibility-${exp.id}-${respIdx}`}>
                      <span className="text-accent mt-0.5 text-base font-mono">▸</span>
                      <span className="flex-1">{resp}</span>
                    </li>
                  ))}
                </ul>

                <div className="pt-4 border-t border-border/30">
                  <div className="flex flex-wrap gap-2">
                    {exp.techStack.map((tech, techIdx) => (
                      <Badge key={techIdx} variant="secondary" className="text-xs font-mono border border-border/30" 
                             data-testid={`badge-tech-${exp.id}-${techIdx}`}>
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
