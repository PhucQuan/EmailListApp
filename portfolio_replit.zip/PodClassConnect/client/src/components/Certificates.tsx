import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Award, ExternalLink, ShieldCheck } from "lucide-react";
import { certificates } from "@/lib/constants";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, scale: 0.9 },
  show: { opacity: 1, scale: 1, transition: { duration: 0.4 } }
};

export default function Certificates() {
  return (
    <section id="certificates" className="py-20 sm:py-24 relative overflow-hidden" data-testid="section-certificates">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 mb-4">
            <ShieldCheck className="w-6 h-6 text-primary" />
            <h2 className="text-3xl sm:text-4xl font-bold font-mono uppercase tracking-widest bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent"
                data-testid="text-certificates-title">
              Certifications
            </h2>
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Chứng chỉ chuyên môn và thành tựu trong lĩnh vực cybersecurity
          </p>
        </motion.div>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {certificates.map((cert) => (
            <motion.div key={cert.id} variants={item}>
              <Card className="p-6 h-full flex flex-col border-border/50 hover-elevate hover-glow-primary bg-gradient-to-br from-card/80 to-background/50 backdrop-blur-sm group relative overflow-hidden" 
                    data-testid={`card-certificate-${cert.id}`}>
                
                {/* Decorative corner */}
                <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-primary/10 to-transparent rounded-bl-full opacity-50 group-hover:opacity-100 transition-opacity"></div>

                <div className="flex items-start gap-3 mb-4 relative z-10">
                  <div className="p-2.5 rounded-lg bg-primary/10 text-primary border border-primary/20 group-hover:border-primary/40 transition-colors">
                    <Award className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-base mb-1 leading-tight group-hover:text-primary transition-colors" 
                        data-testid={`text-cert-name-${cert.id}`}>
                      {cert.name}
                    </h3>
                    <p className="text-sm text-muted-foreground font-mono" data-testid={`text-cert-issuer-${cert.id}`}>
                      {cert.issuer}
                    </p>
                  </div>
                </div>

                <div className="space-y-3 mb-4 relative z-10">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground font-mono text-xs">Issued:</span>
                    <Badge variant="secondary" className="font-mono text-xs border border-border/30" 
                           data-testid={`text-cert-date-${cert.id}`}>
                      {cert.date}
                    </Badge>
                  </div>
                  {cert.credentialId && (
                    <div className="px-3 py-2 rounded-md bg-background/50 border border-border/20">
                      <p className="text-xs text-muted-foreground mb-1 font-mono">Credential ID</p>
                      <p className="text-xs font-mono break-all" data-testid={`text-cert-id-${cert.id}`}>
                        {cert.credentialId}
                      </p>
                    </div>
                  )}
                </div>

                <div className="mt-auto relative z-10">
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full font-mono hover-glow-primary group/btn"
                    asChild
                    data-testid={`button-verify-${cert.id}`}
                  >
                    <a href={cert.verifyUrl} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="w-4 h-4 mr-2 group-hover/btn:rotate-12 transition-transform" />
                      Verify
                    </a>
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
