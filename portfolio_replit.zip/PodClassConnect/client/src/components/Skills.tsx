import { motion } from "framer-motion";
import { Shield, Code, Wrench, Terminal } from "lucide-react";
import { Card } from "@/components/ui/card";
import { skills } from "@/lib/constants";

const skillCategories = [
  {
    title: "Cybersecurity",
    icon: Shield,
    skills: skills.cybersecurity,
    color: "text-primary",
    gradient: "from-primary/20 to-primary/5"
  },
  {
    title: "Programming",
    icon: Code,
    skills: skills.programming,
    color: "text-accent",
    gradient: "from-accent/20 to-accent/5"
  },
  {
    title: "Tools & Others",
    icon: Wrench,
    skills: skills.tools,
    color: "text-chart-3",
    gradient: "from-chart-3/20 to-chart-3/5"
  }
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 30 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5 } }
};

export default function Skills() {
  return (
    <section id="skills" className="py-20 sm:py-24 relative overflow-hidden" data-testid="section-skills">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-96 h-96 bg-primary rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-accent rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 mb-4">
            <Terminal className="w-6 h-6 text-primary" />
            <h2 className="text-3xl sm:text-4xl font-bold font-mono uppercase tracking-widest bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent"
                data-testid="text-skills-title">
              Skills & Expertise
            </h2>
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Chuyên môn kỹ thuật và công cụ tôi sử dụng để bảo vệ hệ thống
          </p>
        </motion.div>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {skillCategories.map((category, idx) => (
            <motion.div key={category.title} variants={item}>
              <Card className={`p-6 h-full border-border/50 hover-elevate hover-glow-primary bg-gradient-to-br ${category.gradient} backdrop-blur-sm`} 
                    data-testid={`card-skill-category-${idx}`}>
                <div className="flex items-center gap-3 mb-6 pb-4 border-b border-border/30">
                  <div className={`p-2 rounded-lg bg-background/50 ${category.color}`}>
                    <category.icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-xl font-semibold font-mono tracking-wide">{category.title}</h3>
                </div>

                <div className="space-y-4">
                  {category.skills.map((skill, skillIdx) => (
                    <div key={skill.name} data-testid={`skill-${idx}-${skillIdx}`}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium font-mono">{skill.name}</span>
                        <span className="text-xs text-muted-foreground font-mono px-2 py-0.5 rounded bg-background/50">
                          {skill.proficiency}%
                        </span>
                      </div>
                      <div className="h-2 bg-background/30 rounded-full overflow-hidden border border-border/20">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${skill.proficiency}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 1, delay: idx * 0.1 + skillIdx * 0.05, ease: "easeOut" }}
                          className={`h-full bg-gradient-to-r ${
                            idx === 0 ? 'from-primary to-primary/60' :
                            idx === 1 ? 'from-accent to-accent/60' :
                            'from-chart-3 to-chart-3/60'
                          } rounded-full relative`}
                          style={{
                            boxShadow: `0 0 10px ${
                              idx === 0 ? 'hsl(var(--primary) / 0.5)' :
                              idx === 1 ? 'hsl(var(--accent) / 0.5)' :
                              'hsl(var(--chart-3) / 0.5)'
                            }`
                          }}
                        >
                          <div className="absolute right-0 top-0 bottom-0 w-1 bg-white/30 rounded-r-full"></div>
                        </motion.div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
