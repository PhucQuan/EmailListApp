import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Github, Star, GitFork, Terminal } from "lucide-react";
import { projects } from "@/lib/constants";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 30 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5 } }
};

export default function Projects() {
  return (
    <section id="projects" className="py-20 sm:py-24 bg-card/20 relative overflow-hidden" data-testid="section-projects">
      {/* Decorative elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-1/4 right-0 w-96 h-96 bg-accent rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 mb-4">
            <Terminal className="w-6 h-6 text-accent" />
            <h2 className="text-3xl sm:text-4xl font-bold font-mono uppercase tracking-widest bg-gradient-to-r from-accent via-primary to-accent bg-clip-text text-transparent"
                data-testid="text-projects-title">
              Featured Projects
            </h2>
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Các dự án bảo mật và công cụ security research
          </p>
        </motion.div>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          {projects.map((project) => (
            <motion.div key={project.id} variants={item}>
              <Card className="p-0 h-full flex flex-col overflow-hidden border-border/50 hover-elevate hover-glow-accent bg-gradient-to-br from-card to-background relative group" 
                    data-testid={`card-project-${project.id}`}>
                
                {/* Terminal window chrome */}
                <div className="h-10 bg-card/80 border-b border-border/50 flex items-center px-4 gap-2">
                  <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-destructive/80"></div>
                    <div className="w-3 h-3 rounded-full bg-chart-4/80"></div>
                    <div className="w-3 h-3 rounded-full bg-chart-2/80"></div>
                  </div>
                  <span className="text-xs font-mono text-muted-foreground ml-2">
                    ~/projects/{project.title.toLowerCase().replace(/\s+/g, '-')}
                  </span>
                </div>

                <div className="p-6 flex-1 flex flex-col">
                  <div className="mb-4">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="text-xl font-semibold font-mono text-primary group-hover:text-accent transition-colors" 
                          data-testid={`text-project-title-${project.id}`}>
                        {project.title}
                      </h3>
                      <div className="flex items-center gap-3 text-muted-foreground text-sm">
                        {project.stars > 0 && (
                          <span className="flex items-center gap-1 font-mono" data-testid={`text-stars-${project.id}`}>
                            <Star className="w-4 h-4 fill-current" />
                            {project.stars}
                          </span>
                        )}
                        {project.forks > 0 && (
                          <span className="flex items-center gap-1 font-mono" data-testid={`text-forks-${project.id}`}>
                            <GitFork className="w-4 h-4" />
                            {project.forks}
                          </span>
                        )}
                      </div>
                    </div>
                    <p className="text-muted-foreground text-sm leading-relaxed mb-4" data-testid={`text-project-desc-${project.id}`}>
                      {project.description}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {project.techStack.map((tech, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs font-mono border border-border/30" 
                               data-testid={`badge-tech-${project.id}-${idx}`}>
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="mt-auto pt-4 border-t border-border/30 flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 font-mono hover-glow-primary"
                      asChild
                      data-testid={`button-github-${project.id}`}
                    >
                      <a href={project.githubUrl} target="_blank" rel="noopener noreferrer">
                        <Github className="w-4 h-4 mr-2" />
                        Source
                      </a>
                    </Button>
                    {project.liveUrl && (
                      <Button
                        size="sm"
                        className="flex-1 font-mono hover-glow-accent"
                        asChild
                        data-testid={`button-live-${project.id}`}
                      >
                        <a href={project.liveUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Demo
                        </a>
                      </Button>
                    )}
                  </div>
                </div>

                {/* Hover glow effect */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                  <div className="absolute inset-0 bg-gradient-to-br from-accent/5 to-primary/5"></div>
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
