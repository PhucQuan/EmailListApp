import { motion } from "framer-motion";
import { ArrowUp, Terminal } from "lucide-react";

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-card/50 border-t border-border/50 py-8 backdrop-blur-sm relative overflow-hidden" data-testid="footer-main">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-primary rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-accent rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-center sm:text-left">
            <div className="flex items-center gap-2 justify-center sm:justify-start mb-2">
              <Terminal className="w-4 h-4 text-primary" />
              <p className="text-sm font-mono text-foreground" data-testid="text-copyright">
                © {new Date().getFullYear()} Trần Hoàng Phúc Quân
              </p>
            </div>
            <p className="text-xs text-muted-foreground font-mono">
              Built with{" "}
              <span className="text-primary">React</span>
              {" + "}
              <span className="text-accent">Tailwind</span>
              {" + "}
              <span className="text-chart-3">Framer Motion</span>
            </p>
          </div>

          <motion.button
            onClick={scrollToTop}
            whileHover={{ scale: 1.1, y: -2 }}
            whileTap={{ scale: 0.95 }}
            className="p-3 rounded-lg bg-gradient-to-br from-primary to-accent text-primary-foreground hover-glow-primary group"
            aria-label="Back to top"
            data-testid="button-back-to-top"
          >
            <ArrowUp className="w-5 h-5 group-hover:-translate-y-0.5 transition-transform" />
          </motion.button>
        </div>
      </div>
    </footer>
  );
}
